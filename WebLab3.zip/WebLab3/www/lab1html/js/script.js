const noticationBar = document.getElementById('hellobar-bar');

let notificationsContainer = document.getElementsByClassName('notifications-container');
const postNotificationForm = document.getElementById('editor_mode');
const filterNotificationForm = document.getElementById('filter-by-name');

postNotificationForm.addEventListener('submit', async function () {

    let notification = {};

    const inputName = document.querySelector('input[name=notification-name]');
    const inputText = document.querySelector('input[name=notification-text]');

    notification.name = inputName.value;
    notification.text = inputText.value;

    try {
        await postNewNotification(notification)
        await getNotifications();
    } catch (e) {
        console.log(e);
    }
});

filterNotificationForm.addEventListener('submit', async function (event) {
    event.preventDefault();
    const filteredName = document.querySelector('input[name=filtering-name]');
    const name = filteredName.value;
    
    const filteredNotifications = await getNotifications(name);
    const filteredContainer = document.getElementById('filtered-notication-container');
    filteredContainer.innerHTML = '';

    for (const notification of filteredNotifications) {
        console.log(notification);

        // Create elements for one notification
        const notificationDiv = document.createElement('div');
        notificationDiv.setAttribute('class', 'notification-card');
        const nameWhoPlaced = document.createElement('h4');
        const notificationText = document.createElement('p');

        // Put text from notification inside new elements
        nameWhoPlaced.innerText = notification.name;
        notificationText.innerText = notification.text;

        notificationDiv.append(nameWhoPlaced, notificationText);
        filteredContainer.append(notificationDiv);
    }

   event.target.reset();
});

loadAllNotificationsToContainer();

async function loadAllNotificationsToContainer() {
    getNotifications().then(respJson => {
    notificationsContainer[0].innerHTML = '';

    for (const notification of respJson) {
        console.log(notification);

        // Create elements for one notification
        const notificationDiv = document.createElement('div');
        notificationDiv.setAttribute('class', 'notification-card');
        const nameWhoPlaced = document.createElement('h4');
        const notificationText = document.createElement('p');
        const deleteBtn = document.createElement('button');

        deleteBtn.addEventListener('click', async function () {
            await deleteNotification(notification.id);
            console.log("ID to delete: " + notification.id);
        })

        // Put text from notification inside new elements
        nameWhoPlaced.innerText = notification.name;
        notificationText.innerText = notification.text;
        deleteBtn.innerText = 'Delete';

        notificationDiv.append(nameWhoPlaced, notificationText, deleteBtn);
        notificationsContainer[0].append(notificationDiv);
    }

});
}


// Get notifications request
async function getNotifications(name) {
    // If no name was provided, set name to empty string
    console.log(name)
    let query = "";
    if (name) {
        query = "?name=" + name;
    }
    console.log(query)
    
    const response = await fetch('http://localhost:3000/info' + query);
    const respJson = await response.json();

    console.log(respJson)
    return respJson;
}

// Post new notification
async function postNewNotification(notification) {

    try {
        const response = await fetch('http://localhost:3000/info', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(notification)
        });

        await response.json();

    } catch (e) {
        console.error(e);
        alert("ALLLEERRRTTT");
    }
}

async function deleteNotification(id) {
    const response = await fetch('http://localhost:3000/info/' + id, {
        method: "DELETE"
    });

    if (response.ok) {
        await loadAllNotificationsToContainer();
    } else {
        alert("ALLLEEERT");
    }

}