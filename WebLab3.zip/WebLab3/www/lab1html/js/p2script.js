let notifications;
const noticationBar = document.getElementById('hellobar-bar');

getNotifications().then(respJson => {
    if (respJson.length > 0) {
        const headlineBarText = document.getElementsByClassName('hb-headline-text')[0];

        // Create elements for one notification
        const textToShow = document.createElement('p');

        // Put text from notification inside new elements
        textToShow.innerText = respJson[respJson.length-1].name + ': ' + respJson[respJson.length-1].text;

        headlineBarText.append(textToShow);
                
        noticationBar.style.display = 'table';
    }
});

const iconClose = document.getElementById('icon-close');

iconClose.addEventListener('click', function () {
    noticationBar.style.display = 'none';
});

// Get notifications request
async function getNotifications() {
    
    const response = await fetch('http://localhost:3000/info');
    const respJson = await response.json();

    console.log(respJson)
    return respJson;
}