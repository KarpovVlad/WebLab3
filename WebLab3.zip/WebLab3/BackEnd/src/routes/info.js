const express = require('express');
const router = express.Router();
const fs = require('fs');

function getDataFromJson() {
    const rawNotificationsData = fs.readFileSync('./src/data/notifications.json');
    return JSON.parse(rawNotificationsData);
}

router.get('', ((req, res) => {
    console.log("Get request called!");

    const notificationsJson = getDataFromJson()

    if (Object.keys(req.query).length === 0) {
        res.send(notificationsJson);
    } else {
        const filters = req.query;

        // Arrays to store keys and values that are in the query
        let values = [];
        let keys = [];

        // Loop through keys of the received query
        for (const key in filters) {

            keys.push(key);
            values.push(filters[key]);
            console.log(key, filters[key])

        }

        // Using array.filter() to return the list of items which keys' values match searching ones
        const result = notificationsJson.filter(function(e) {
            return keys.every(function(a) {
                return values.includes(e[a]);
            });
        });

        res.send(result);
    }

}));

router.post("", (req, res) => {

    const notificationsJson = getDataFromJson();

    const tryToAddNotification = req.body;
    let lastNotification;
    if (notificationsJson.length !== 0) {
        lastNotification = notificationsJson[notificationsJson.length - 1];
    } else {
        lastNotification = null;
    }

    let notificationNew = {};

    if (lastNotification != null) {
        notificationNew.id = lastNotification.id + 1;
    } else {
        notificationNew.id = 0;
    }
    notificationNew.name = tryToAddNotification.name || "noname";
    notificationNew.text = tryToAddNotification.text;

    notificationsJson.push(notificationNew);

    const notificationsNew = JSON.stringify(notificationsJson);

    fs.writeFileSync('./src/data/notifications.json', notificationsNew);

    res.status(201).send(notificationNew);
});

router.delete("/:id", (req, res) => {
    let notificationsArray = getDataFromJson();

    for (const notificationsArrayElement of notificationsArray) {
        if (notificationsArrayElement.id == req.params.id) {
            notificationsArray.splice(notificationsArrayElement.id, 1);
        }
    }

    const notificationsUpdated = JSON.stringify(notificationsArray);
    fs.writeFileSync('./src/data/notifications.json', notificationsUpdated);

    res.status(200).send(getDataFromJson());
})
module.exports = router;